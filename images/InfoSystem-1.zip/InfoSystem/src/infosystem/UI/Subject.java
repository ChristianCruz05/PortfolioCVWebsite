/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infosystem.UI;

import java.time.LocalTime;


public class Subject {  
    private String code;
    private String name;
    private String instructor;
    private LocalTime start, end; 

    
    public Subject(){
        this.code = "default code";
        this.name = "default name";
        this.instructor = "default instructor";
        this.start = LocalTime.of(9, 0);
        this.end = LocalTime.of(10, 0);
    }
    
    public Subject(String code, String name, String instructor, LocalTime start, LocalTime end) {
    this.code = code;
    this.name = name;
    this.instructor = instructor;
    this.start = start;
    this.end = end;
    }
    
    public void DebugInfo(){
        System.out.println("Subject Code: " + this.code);
        System.out.println("Subject Name: " + this.name);
        System.out.println("Subject instructir: " + this.instructor);
        System.out.println("Subject Starts at: " + this.start);
        System.out.println("Subject Ends at: " + this.end);
    }
    public String getCode() {
        return code;
    }

    public void setCode(String code) {
        this.code = code;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getInstructor() {
        return instructor;
    }

    public void setInstructor(String instructor) {
        this.instructor = instructor;
    }

    public LocalTime getStart() {
        return start;
    }

    public void setStart(LocalTime start) {
        this.start = start;
    }

    public LocalTime getEnd() {
        return end;
    }

    public void setEnd(LocalTime end) {
        this.end = end;
    }
}
