/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infosystem.UI;

import java.time.LocalTime;
import java.util.Date;
import java.util.LinkedList;

public class DataHandler {
    public static class Students{
        public static Student sampleStudent = new Student();
        public static LinkedList<Subject> availableSubjects = new LinkedList();
        public static void CreateSamples(){
            sampleStudent = new Student("sample last", "sample first", "sample middle");
            sampleStudent.setAddress("123 default address");
            sampleStudent.setBirthDate(new Date(2004, 4, 15));
            sampleStudent.setContactNumber("09111111111");
            sampleStudent.setGradeLevel(11);
            sampleStudent.setSection(Section.Python);
            sampleStudent.setEmail("sample@email.com");
            sampleStudent.setPassword("password");
        }
        
        public static void CreateSubjects(){
            Subject tempSubject1 = new Subject("111-AAA", "Computer Programming", "Bille Janssen Lagarde", LocalTime.of(8,0), LocalTime.of(10, 0));
            sampleStudent.AddSubjects(tempSubject1);
            
            Subject tempSubject2 = new Subject("111-BBB", "Applications and Emerging Technologies", "Gabriel Avelino Sampedro", LocalTime.of(8,0), LocalTime.of(10, 0));
            sampleStudent.AddSubjects(tempSubject2);
            
            Subject tempSubject3 = new Subject("111-CCC", "Oral Communication", "Miriam Estrada Rana", LocalTime.of(8,0), LocalTime.of(10, 0));
            sampleStudent.AddSubjects(tempSubject3);
            
            Subject tempSubject4 = new Subject("111-DDD", "Practical Research", "Camille Erika Jan Velasco", LocalTime.of(8,0), LocalTime.of(10, 0));
            sampleStudent.AddSubjects(tempSubject4);
            
            Subject tempSubject5 = new Subject("111-EEE", "Statistics and Probability", "Camille B. Secong", LocalTime.of(8,0), LocalTime.of(10, 0));
            sampleStudent.AddSubjects(tempSubject5);
        }
    }
    public enum Section{
        Hue, Pattern, Python, Symmetry, Unity, Vision, Balance, Harmony, Java, Max, Maya, Rhythm
    }
}
