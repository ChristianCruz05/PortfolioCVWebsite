/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package infosystem.UI;

import java.util.Date;
import java.util.LinkedList;
import infosystem.UI.DataHandler.Section;

public class Student {
    private String lastName;
    private String firstName;
    private String middleName;
    
    private Date birthDate;
    private String address;
    private String contactNumber;
    private String email;
    private String password;
    private int gradeLevel;
    private Section section;
    private LinkedList<Subject> subjectsEnrolled = new LinkedList();
    
    public Student(){
        this.lastName = "last name";
        this.firstName = "first name";
        this.middleName = "middle name";
        this.birthDate = new Date(1990, 1, 1);
        this.address = "default address 123";
        this.contactNumber = "09111111111";
        this.email = "sample@email.com";
        this.password = "password";
        
    }
    
    public Student(String email, String password){
        this.lastName = "last name";
        this.firstName = "first name";
        this.middleName = "middle name";
        this.birthDate = new Date(1990, 1, 1);
        this.address = "default address 123";
        this.contactNumber = "09111111111";
        this.email = email;
        this.password = password;        
    }
    
    public Student(String lastName, String firstName, String middleName) {
        this.lastName = lastName;
        this.firstName = firstName;
        this.middleName = middleName;
        this.birthDate = new Date(1990, 1, 1);
        this.address = "default address 123";
        this.contactNumber = "09111111111";
        this.email = "sample@email.com";
        this.password = "password";
    }
    
    
    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }
    
    public Date getBirthDate() {
        return birthDate;
    }

    public void setBirthDate(Date birthDate) {
        this.birthDate = birthDate;
    }
    
    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getContactNumber() {
        return contactNumber;
    }

    public void setContactNumber(String contactNumber) {
        this.contactNumber = contactNumber;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }
    
    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
    
    public int getGradeLevel() {
        return gradeLevel;
    }

    public void setGradeLevel(int gradeLevel) {
        this.gradeLevel = gradeLevel;
    }

    public Section getSection() {
        return section;
    }

    public void setSection(Section section) {
        this.section = section;
    }

    public LinkedList<Subject> getSubjectsEnrolled() {
        return subjectsEnrolled;
    }

    public void setSubjectsEnrolled(LinkedList<Subject> subjectsEnrolled) {
        this.subjectsEnrolled = subjectsEnrolled;
    }
    
    public void DebugInfo(){
        System.out.println("Last Name: " + this.lastName);
        System.out.println("First Name: " + this.firstName);
        System.out.println("Middle Name: " + this.middleName);
        //System.out.println("Birth Date: " + this.birthDate.getMonth() + " " + this.birthDate.getDate() + ", " + this.birthDate.getYear());
        System.out.println("BirthDate: " + this.getBirthDate());
        System.out.println("Address: " + this.address);
        System.out.println("Contact Number: " + this.contactNumber);
        System.out.println("Email: " + this.email);
    }
    
    public void AddSubjects(Subject subject){
        this.subjectsEnrolled.add(subject);
    }
}
